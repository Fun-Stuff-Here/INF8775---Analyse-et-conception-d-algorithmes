class Encloser:
    def __init__(self, encloser_number: int, size: int) -> None:
        self.encloser_number: int = encloser_number
        self.size: int = size
